# Plano arquitetural executável para MyFuckingLife

## 1. Objetivo e princípios

### 1.1 Objetivo
Definir a arquitetura-base executável do projeto **MyFuckingLife** para implementação faseada de um sistema completo de gestão de vida pessoal e profissional usando **Next.js 14 App Router**, **TypeScript**, **TailwindCSS**, **shadcn/ui**, **Prisma**, **PostgreSQL**, **NextAuth.js**, **Zod** e **uploads locais**.

### 1.2 Princípios arquiteturais
- **Isolamento total por usuário**: toda leitura, escrita, update e delete deve filtrar por `userId`.
- **Server-first**: priorizar Server Components para leitura e composição de página; usar Client Components apenas quando houver interatividade real.
- **Validação em duas camadas**: frontend e backend com schemas Zod compartilhados.
- **Contratos consistentes**: respostas padronizadas, erros previsíveis, paginação e filtros uniformes.
- **Segurança pragmática**: autenticação robusta, criptografia reversível apenas onde necessário, uploads protegidos, prevenção de path traversal.
- **Implementação incremental**: cada fase deve entregar valor testável sem bloquear a próxima.

### 1.3 Premissas
- Banco principal: **PostgreSQL**.
- Sessão de autenticação: **JWT stateless** via NextAuth.
- Uploads locais em `C:/Users/Marco/projects/myfuckinglife/uploads`.
- Tamanho máximo por arquivo: **10 MB**.
- Tipos aceitos: **PDF, JPG, JPEG, PNG**.
- Sem multi-tenant entre usuários; o isolamento é por conta autenticada.

---

## 2. Arquitetura geral

### 2.1 Estrutura de pastas

```text
C:/Users/Marco/projects/myfuckinglife/
├── app/
│   ├── (auth)/
│   │   ├── login/
│   │   ├── signup/
│   │   ├── forgot-password/
│   │   └── reset-password/[token]/
│   ├── (dashboard)/
│   │   ├── dashboard/
│   │   ├── agenda/
│   │   ├── servicos/
│   │   ├── contas/
│   │   ├── prestadores/
│   │   ├── compras/
│   │   ├── metas/
│   │   ├── notificacoes/
│   │   ├── search/
│   │   └── layout.tsx
│   ├── api/
│   │   ├── auth/[...nextauth]/route.ts
│   │   ├── auth/signup/route.ts
│   │   ├── auth/forgot-password/route.ts
│   │   ├── auth/reset-password/route.ts
│   │   ├── uploads/route.ts
│   │   ├── agenda/...
│   │   ├── servicos/...
│   │   ├── contas/...
│   │   ├── prestadores/...
│   │   ├── compras/...
│   │   ├── metas/...
│   │   ├── dashboard/summary/route.ts
│   │   ├── search/global/route.ts
│   │   └── notifications/route.ts
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── ui/
│   ├── layout/
│   ├── shared/
│   ├── forms/
│   ├── data-table/
│   ├── file-upload/
│   ├── search/
│   ├── dashboard/
│   ├── agenda/
│   ├── servicos/
│   ├── contas/
│   ├── prestadores/
│   ├── compras/
│   └── metas/
├── lib/
│   ├── auth/
│   ├── prisma.ts
│   ├── zod/
│   ├── validations/
│   ├── api/
│   ├── errors/
│   ├── crypto/
│   ├── uploads/
│   ├── email/
│   ├── search/
│   ├── notifications/
│   ├── formatters/
│   ├── constants/
│   └── utils.ts
├── prisma/
│   ├── schema.prisma
│   ├── seed.ts
│   └── migrations/
├── public/
│   ├── icons/
│   ├── images/
│   └── placeholders/
├── uploads/
│   ├── temp/
│   ├── agenda/
│   ├── servicos/
│   ├── contas/
│   ├── prestadores/
│   ├── compras/
│   └── metas/
├── docs/
│   └── PLAN.md
├── middleware.ts
├── components.json
├── tailwind.config.ts
├── postcss.config.js
├── next.config.js
├── tsconfig.json
├── package.json
├── .env
├── .env.example
└── docker-compose.yml
```

### 2.2 Convenções

#### Server Components vs Client Components
- **Server Components por padrão** para:
  - páginas de listagem inicial;
  - carregamento de summaries do dashboard;
  - composição de layout autenticado;
  - leitura de sessão.
- **Client Components apenas quando necessário**:
  - formulários com estado local;
  - tabelas com sort interativo;
  - date pickers;
  - upload com preview/progresso;
  - sidebar colapsável;
  - busca global com debounce/atalho;
  - toasts, modais, confirmações.

#### Server Actions vs API Routes
**Decisão**: usar modelo **híbrido**, com preferência funcional por **API Routes** como contrato principal e **Server Actions** só para mutações locais simples em formulários pequenos.

#### API Routes para:
- CRUDs dos módulos;
- uploads binários;
- autenticação auxiliar (signup, forgot, reset);
- busca global;
- notificações;
- endpoints que precisem ser reutilizados por diferentes telas;
- fluxos que exijam status code explícito e contrato HTTP claro.

#### Server Actions para:
- ações pontuais internas de tela, como toggle simples, marcar pago/comprado, atualização inline;
- operações que não envolvam arquivo binário.

### Padrão de erros
Criar `AppError` com estrutura:
- `code`
- `message`
- `details`
- `httpStatus`

Códigos base:
- `UNAUTHORIZED`
- `FORBIDDEN`
- `NOT_FOUND`
- `VALIDATION_ERROR`
- `CONFLICT`
- `PAYLOAD_TOO_LARGE`
- `UNSUPPORTED_FILE_TYPE`
- `RATE_LIMITED`
- `INTERNAL_ERROR`

### Padrão de resposta
Para APIs REST:

```ts
{
  success: boolean,
  data?: T,
  error?: {
    code: string,
    message: string,
    details?: unknown
  },
  meta?: {
    page?: number,
    pageSize?: number,
    total?: number,
    totalPages?: number
  }
}
```

## 2.3 Estratégia de autenticação
- NextAuth.js com **Credentials Provider**.
- Usuário autentica por **email + senha**.
- Senha principal armazenada com **hash Argon2id**.
- Sessão via **JWT**.
- `middleware.ts` protege todas as rotas de `/(dashboard)` e APIs privadas.
- O JWT deve carregar no mínimo:
  - `sub`
  - `email`
  - `name`
- Toda query Prisma de módulo deve sempre incluir `where: { userId: session.user.id }`.
- Toda criação deve injetar `userId` do usuário autenticado, nunca vindo do payload do cliente.

## 2.4 Estratégia de uploads

### Regras
- MIME permitido: `application/pdf`, `image/jpeg`, `image/png`.
- Extensões permitidas: `.pdf`, `.jpg`, `.jpeg`, `.png`.
- Tamanho máximo: `10 * 1024 * 1024`.
- Nome físico do arquivo: `userId/entityType/yyyy/mm/<uuid>.<ext>`.
- Nome original preservado apenas em metadado.

### Segurança
- Normalizar nome e ignorar qualquer path vindo do cliente.
- Proibir uso de nome informado pelo cliente como path final.
- Validar **mime + extensão + assinatura mágica** sempre que possível.
- Salvar fora de `public/` para evitar exposição direta.
- Download/preview sempre mediado por rota autenticada.
- Limpar arquivos órfãos após falha transacional.

### Decisão
Manter uploads em `C:/Users/Marco/projects/myfuckinglife/uploads` com acesso controlado por API, e **não** em `public/`, para evitar exposição direta e simplificar autorização.

## 2.5 Fluxo macro

```mermaid
flowchart TD
    U[Usuário] --> UI[App Router UI]
    UI --> MW[Middleware Auth]
    MW --> PAGES[Páginas protegidas]
    PAGES --> API[API Routes / Server Actions]
    API --> ZOD[Validação Zod]
    ZOD --> AUTH[Autorização e userId scope]
    AUTH --> PRISMA[Prisma]
    AUTH --> FS[Uploads locais]
    PRISMA --> DB[(PostgreSQL)]
    FS --> FILES[(uploads/)]
```

---

## 3. Schema Prisma completo

### 3.1 Convenções de modelagem
- Todos os modelos de negócio terão:
  - `id String @id @default(cuid())`
  - `userId String`
  - `createdAt DateTime @default(now())`
  - `updatedAt DateTime @updatedAt`
- Todos terão `@@index([userId])`.
- Valores financeiros: `Decimal @db.Decimal(12, 2)`.
- Campos opcionais apenas quando o domínio realmente permitir ausência.
- `onDelete: Cascade` em todas as relações filhas do `User`.

### 3.2 Enums

```prisma
enum TipoCompromisso {
  REUNIAO
  CONSULTA
  ENTREGA
  EVENTO
  PESSOAL
  PROFISSIONAL
  OUTRO
}

enum RecorrenciaTipo {
  NENHUMA
  DIARIA
  SEMANAL
  QUINZENAL
  MENSAL
  ANUAL
}

enum CategoriaServico {
  STREAMING
  SOFTWARE
  HOSPEDAGEM
  DOMINIO
  EDUCACAO
  BANCO
  REDES_SOCIAIS
  UTILITARIO
  OUTRO
}

enum StatusServico {
  ATIVO
  PAUSADO
  CANCELADO
  ATRASADO
}

enum StatusConta {
  A_PAGAR
  PAGA
  ATRASADA
  CANCELADA
}

enum Recorrencia {
  NENHUMA
  SEMANAL
  QUINZENAL
  MENSAL
  BIMESTRAL
  TRIMESTRAL
  SEMESTRAL
  ANUAL
}

enum TipoVinculo {
  CLT
  PJ
  FREELANCER
  TEMPORARIO
  ESTAGIO
  OUTRO
}

enum StatusVinculo {
  ATIVO
  INATIVO
  SUSPENSO
  ENCERRADO
}

enum TipoDocumentoPrestador {
  RG
  CPF
  CNH
  COMPROVANTE_RESIDENCIA
  CONTRATO
  CERTIFICADO
  OUTRO
}

enum Urgencia {
  BAIXA
  MEDIA
  ALTA
}

enum CategoriaProduto {
  ALIMENTO
  LIMPEZA
  HIGIENE
  FARMACIA
  CASA
  ESCRITORIO
  ELETRONICO
  ROUPA
  OUTRO
}

enum CategoriaMeta {
  PESSOAL
  PROFISSIONAL
  FINANCEIRA
  SAUDE
  ESTUDO
  RELACIONAMENTO
  OUTRO
}

enum StatusMeta {
  NAO_INICIADA
  EM_ANDAMENTO
  CONCLUIDA
  PAUSADA
  CANCELADA
}

enum Prioridade {
  BAIXA
  MEDIA
  ALTA
}

enum UploadEntityType {
  AGENDA
  SERVICO
  CONTA
  PRESTADOR
  ITEM_COMPRA
  META
  ENTRADA_DIARIO
  MARCO
}

enum NotificationType {
  INFO
  SUCCESS
  WARNING
  ERROR
}
```

### 3.3 Modelos de autenticação

```prisma
model User {
  id                 String               @id @default(cuid())
  name               String
  email              String               @unique
  passwordHash       String
  emailVerified      DateTime?
  image              String?
  accounts           Account[]
  sessions           Session[]
  passwordResetTokens PasswordResetToken[]
  compromissos       Compromisso[]
  servicos           Servico[]
  contas             Conta[]
  prestadores        Prestador[]
  itensCompra        ItemCompra[]
  metas              Meta[]
  uploads            Upload[]
  notifications      Notification[]
  createdAt          DateTime             @default(now())
  updatedAt          DateTime             @updatedAt
}

model Account {
  userId             String
  type               String
  provider           String
  providerAccountId  String
  refresh_token      String?
  access_token       String?
  expires_at         Int?
  token_type         String?
  scope              String?
  id_token           String?
  session_state      String?
  user               User                 @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@id([provider, providerAccountId])
  @@index([userId])
}

model Session {
  sessionToken       String               @unique
  userId             String
  expires            DateTime
  user               User                 @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@id([sessionToken])
  @@index([userId])
}

model VerificationToken {
  identifier         String
  token              String               @unique
  expires            DateTime

  @@id([identifier, token])
}

model PasswordResetToken {
  id                 String               @id @default(cuid())
  userId             String
  tokenHash          String               @unique
  expiresAt          DateTime
  usedAt             DateTime?
  user               User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  createdAt          DateTime             @default(now())
  updatedAt          DateTime             @updatedAt

  @@index([userId])
  @@index([expiresAt])
}
```

### 3.4 Agenda

```prisma
model Compromisso {
  id                 String               @id @default(cuid())
  userId             String
  titulo             String
  descricao          String?
  local              String?
  dataInicio         DateTime
  dataFim            DateTime?
  diaInteiro         Boolean              @default(false)
  tipo               TipoCompromisso
  cor                String?
  recorrencia        RecorrenciaTipo      @default(NENHUMA)
  recorrenciaFim     DateTime?
  alertaMinutos      Int?
  observacao         String?
  user               User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  uploads            Upload[]
  createdAt          DateTime             @default(now())
  updatedAt          DateTime             @updatedAt

  @@index([userId])
  @@index([userId, dataInicio])
  @@index([userId, tipo])
}
```

### 3.5 Acessos / Assinaturas

```prisma
model Servico {
  id                 String               @id @default(cuid())
  userId             String
  nome               String
  logoUploadId       String?
  login              String
  senhaEncrypted     String
  senhaIv            String
  senhaAuthTag       String
  url                String?
  categoria          CategoriaServico
  valorMensal        Decimal              @db.Decimal(12, 2)
  diaVencimento      Int
  status             StatusServico        @default(ATIVO)
  observacao         String?
  user               User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  logoUpload         Upload?              @relation("ServicoLogo", fields: [logoUploadId], references: [id], onDelete: SetNull)
  uploads            Upload[]             @relation("ServicoUploads")
  createdAt          DateTime             @default(now())
  updatedAt          DateTime             @updatedAt

  @@index([userId])
  @@index([userId, categoria])
  @@index([userId, status])
  @@index([userId, diaVencimento])
}
```

### 3.6 Contas a pagar

```prisma
model Conta {
  id                 String               @id @default(cuid())
  userId             String
  nome               String
  valor              Decimal              @db.Decimal(12, 2)
  vencimento         DateTime
  dataPagamento      DateTime?
  status             StatusConta          @default(A_PAGAR)
  mesReferencia      DateTime
  recorrencia        Recorrencia          @default(NENHUMA)
  observacao         String?
  user               User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  uploads            Upload[]             @relation("ContaUploads")
  createdAt          DateTime             @default(now())
  updatedAt          DateTime             @updatedAt

  @@index([userId])
  @@index([userId, status])
  @@index([userId, vencimento])
  @@index([userId, mesReferencia])
}
```

### 3.7 Prestadores

```prisma
model Prestador {
  id                   String               @id @default(cuid())
  userId               String
  nome                 String
  cpf                  String?
  rg                   String?
  dataNascimento       DateTime?
  naturalidade         String?
  email                String?
  telefone             String?
  cep                  String?
  logradouro           String?
  numero               String?
  complemento          String?
  bairro               String?
  cidade               String?
  estado               String?
  cargo                String?
  tipoVinculo          TipoVinculo
  statusVinculo        StatusVinculo        @default(ATIVO)
  dataInicio           DateTime?
  dataFim              DateTime?
  salario              Decimal?             @db.Decimal(12, 2)
  diaPagamento         Int?
  formaPagamento       String?
  pixChave             String?
  bancoNome            String?
  bancoAgencia         String?
  bancoConta           String?
  observacao           String?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  documentos           DocumentoPrestador[]
  uploads              Upload[]             @relation("PrestadorUploads")
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, statusVinculo])
  @@index([userId, tipoVinculo])
  @@index([userId, diaPagamento])
  @@index([userId, nome])
}

model DocumentoPrestador {
  id                   String                 @id @default(cuid())
  userId               String
  prestadorId          String
  tipo                 TipoDocumentoPrestador
  nome                 String
  descricao            String?
  uploadId             String
  prestador            Prestador              @relation(fields: [prestadorId], references: [id], onDelete: Cascade)
  user                 User                   @relation(fields: [userId], references: [id], onDelete: Cascade)
  upload               Upload                 @relation(fields: [uploadId], references: [id], onDelete: Cascade)
  createdAt            DateTime               @default(now())
  updatedAt            DateTime               @updatedAt

  @@index([userId])
  @@index([userId, prestadorId])
  @@index([userId, tipo])
}
```

### 3.8 Lista de compras

```prisma
model ItemCompra {
  id                   String               @id @default(cuid())
  userId               String
  nome                 String
  quantidade           Decimal?             @db.Decimal(10, 2)
  unidade              String?
  localCompra          String?
  urgencia             Urgencia             @default(MEDIA)
  categoria            CategoriaProduto     @default(OUTRO)
  observacao           String?
  comprado             Boolean              @default(false)
  dataCompra           DateTime?
  valorEstimado        Decimal?             @db.Decimal(12, 2)
  valorReal            Decimal?             @db.Decimal(12, 2)
  origemItemId         String?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  uploads              Upload[]             @relation("CompraUploads")
  origemItem           ItemCompra?          @relation("CompraDuplicada", fields: [origemItemId], references: [id], onDelete: SetNull)
  derivados            ItemCompra[]         @relation("CompraDuplicada")
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, comprado])
  @@index([userId, urgencia])
  @@index([userId, categoria])
}
```

### 3.9 Metas

```prisma
model Meta {
  id                   String               @id @default(cuid())
  userId               String
  titulo               String
  descricao            String?
  categoria            CategoriaMeta
  prazo                DateTime?
  status               StatusMeta           @default(NAO_INICIADA)
  prioridade           Prioridade           @default(MEDIA)
  motivacao            String?
  progressoManual      Int?                 
  concluidaEm          DateTime?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  marcos               Marco[]
  diario               EntradaDiario[]
  uploads              Upload[]             @relation("MetaUploads")
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, status])
  @@index([userId, categoria])
  @@index([userId, prioridade])
  @@index([userId, prazo])
}

model Marco {
  id                   String               @id @default(cuid())
  userId               String
  metaId               String
  titulo               String
  descricao            String?
  ordem                Int
  concluido            Boolean              @default(false)
  concluidoEm          DateTime?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  meta                 Meta                 @relation(fields: [metaId], references: [id], onDelete: Cascade)
  uploads              Upload[]             @relation("MarcoUploads")
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, metaId])
  @@index([userId, concluido])
}

model EntradaDiario {
  id                   String               @id @default(cuid())
  userId               String
  metaId               String
  conteudo             String
  humor                String?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  meta                 Meta                 @relation(fields: [metaId], references: [id], onDelete: Cascade)
  uploads              Upload[]             @relation("DiarioUploads")
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, metaId])
  @@index([metaId, createdAt])
}
```

### 3.10 Upload genérico

#### Decisão
Adotar **upload genérico centralizado** com `entityType` + `entityId`, complementado por relações explícitas onde agregam valor real (`Servico.logoUpload`, `DocumentoPrestador.uploadId`).

#### Justificativa
- reduz duplicação de tabela por módulo;
- simplifica busca de anexos recentes e limpeza centralizada;
- suporta anexos em múltiplas entidades;
- mantém flexibilidade para preview, auditoria e reuso.

#### Modelo

```prisma
model Upload {
  id                   String               @id @default(cuid())
  userId               String
  entityType           UploadEntityType
  entityId             String
  modulo               String
  categoria            String?
  originalName         String
  storagePath          String
  mimeType             String
  extension            String
  sizeBytes            Int
  checksum             String?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  servicoLogoOf        Servico[]            @relation("ServicoLogo")
  servicoUploads       Servico[]            @relation("ServicoUploads")
  contaUploads         Conta[]              @relation("ContaUploads")
  prestadorUploads     Prestador[]          @relation("PrestadorUploads")
  compraUploads        ItemCompra[]         @relation("CompraUploads")
  metaUploads          Meta[]               @relation("MetaUploads")
  compromissoUploads   Compromisso[]
  marcoUploads         Marco[]              @relation("MarcoUploads")
  diarioUploads        EntradaDiario[]      @relation("DiarioUploads")
  documentosPrestador  DocumentoPrestador[]
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, entityType, entityId])
  @@index([userId, modulo])
}
```

### 3.11 Notificações

```prisma
model Notification {
  id                   String               @id @default(cuid())
  userId               String
  tipo                 NotificationType
  titulo               String
  mensagem             String
  lida                 Boolean              @default(false)
  link                 String?
  referenciaModulo     String?
  referenciaId         String?
  dispararEm           DateTime?
  user                 User                 @relation(fields: [userId], references: [id], onDelete: Cascade)
  createdAt            DateTime             @default(now())
  updatedAt            DateTime             @updatedAt

  @@index([userId])
  @@index([userId, lida])
  @@index([userId, dispararEm])
}
```

### 3.12 Regras de cascade
- `User -> *`: `Cascade`.
- `Prestador -> DocumentoPrestador`: `Cascade`.
- `Meta -> Marco`, `Meta -> EntradaDiario`: `Cascade`.
- `Upload` vinculado a `DocumentoPrestador`: `Cascade` na exclusão do documento.
- `Servico.logoUploadId`: `SetNull` para não quebrar o serviço se a logo for removida.
- `ItemCompra.origemItemId`: `SetNull`.

---

## 4. Contratos de API

### 4.1 Convenções gerais
- Prefixo: `/api`.
- Paginação padrão: `page`, `pageSize`.
- Ordenação: `sortBy`, `sortOrder`.
- Filtros por query string em listagens.
- Todas as rotas privadas exigem sessão válida.

### 4.2 Auth

#### `POST /api/auth/signup`
**Entrada (Zod)**
- `name: string().min(2).max(120)`
- `email: string().email()`
- `password: string().min(8).max(72)`
- `confirmPassword: string()` com refine de igualdade

**Resposta**
- `201 { success: true, data: { userId, email } }`

**Erros**
- `400 VALIDATION_ERROR`
- `409 CONFLICT` email já cadastrado
- `500 INTERNAL_ERROR`

#### `POST /api/auth/forgot-password`
**Entrada**
- `email: string().email()`

**Resposta**
- `200 { success: true }` sempre, para evitar enumeração

**Erros**
- `400 VALIDATION_ERROR`
- `500 INTERNAL_ERROR`

#### `POST /api/auth/reset-password`
**Entrada**
- `token: string().min(1)`
- `password: string().min(8).max(72)`
- `confirmPassword: string()`

**Resposta**
- `200 { success: true }`

**Erros**
- `400 VALIDATION_ERROR`
- `401 UNAUTHORIZED` token inválido/expirado/usado
- `500 INTERNAL_ERROR`

### 4.3 Dashboard

#### `GET /api/dashboard/summary`
**Resposta**
- cards agregados:
  - compromissos do dia
  - total mensal de serviços
  - contas pendentes / atrasadas
  - prestadores com pagamento próximo
  - itens urgentes de compra
  - metas ativas / concluídas

**Erros**
- `401 UNAUTHORIZED`
- `500 INTERNAL_ERROR`

### 4.4 Agenda

#### `GET /api/agenda`
**Query**
- `view: enum(month|week|list)`
- `from: date`
- `to: date`
- `tipo?: TipoCompromisso`
- `search?: string`

**Resposta**
- lista de compromissos no intervalo

#### `POST /api/agenda`
**Entrada**
- `titulo: string().min(1).max(160)`
- `descricao?: string().max(2000)`
- `local?: string().max(160)`
- `dataInicio: coerce.date()`
- `dataFim?: coerce.date()`
- `diaInteiro: boolean().default(false)`
- `tipo: nativeEnum(TipoCompromisso)`
- `cor?: string().regex(/^#([A-Fa-f0-9]{6})$/)`
- `recorrencia: nativeEnum(RecorrenciaTipo)`
- `recorrenciaFim?: coerce.date()`
- `alertaMinutos?: number().int().min(0).max(10080)`
- `observacao?: string().max(2000)`

#### `GET /api/agenda/:id`
#### `PATCH /api/agenda/:id`
#### `DELETE /api/agenda/:id`

**Erros comuns**
- `400 VALIDATION_ERROR`
- `401 UNAUTHORIZED`
- `404 NOT_FOUND`

### 4.5 Serviços / Assinaturas

#### `GET /api/servicos`
**Query**
- `search?`
- `categoria?`
- `status?`
- `dueInDays?`
- `page`
- `pageSize`
- `sortBy`
- `sortOrder`

#### `POST /api/servicos`
**Entrada**
- `nome: string().min(1).max(160)`
- `login: string().min(1).max(160)`
- `senha: string().min(1).max(255)`
- `url?: string().url()`
- `categoria: nativeEnum(CategoriaServico)`
- `valorMensal: coerce.number().positive()`
- `diaVencimento: number().int().min(1).max(31)`
- `status: nativeEnum(StatusServico).default(ATIVO)`
- `observacao?: string().max(2000)`
- `logoUploadId?: string().cuid()`
- `uploadIds?: array(string().cuid()).max(10)`

#### `GET /api/servicos/:id`
#### `PATCH /api/servicos/:id`
#### `DELETE /api/servicos/:id`
#### `POST /api/servicos/:id/reveal-password`
Retorna senha decriptada apenas para a sessão autenticada.

#### `POST /api/servicos/:id/copy-password`
Opcionalmente desnecessária no backend; preferir reveal sob demanda no frontend.

### 4.6 Contas a pagar

#### `GET /api/contas`
**Query**
- `status?`
- `mesReferencia?`
- `vencimentoFrom?`
- `vencimentoTo?`
- `search?`
- paginação e ordenação padrão

#### `POST /api/contas`
**Entrada**
- `nome: string().min(1).max(160)`
- `valor: coerce.number().positive()`
- `vencimento: coerce.date()`
- `dataPagamento?: coerce.date()`
- `status?: nativeEnum(StatusConta)`
- `mesReferencia: coerce.date()`
- `recorrencia: nativeEnum(Recorrencia)`
- `observacao?: string().max(2000)`
- `uploadIds?: array(string().cuid()).max(10)`

#### `PATCH /api/contas/:id/mark-paid`
**Entrada**
- `dataPagamento?: coerce.date()`

**Resposta**
- conta atualizada com status `PAGA`

#### `GET /api/contas/:id`
#### `PATCH /api/contas/:id`
#### `DELETE /api/contas/:id`

### 4.7 Prestadores

#### `GET /api/prestadores`
**Query**
- `search?`
- `statusVinculo?`
- `tipoVinculo?`
- `paymentDueInDays?`
- paginação/ordenação

#### `POST /api/prestadores`
**Entrada**
- campos pessoais, endereço, contratuais e bancários conforme schema Prisma
- validações especiais:
  - `cpf` com regex/normalização
  - `email` email válido
  - `diaPagamento` entre 1 e 31
  - `salario` número positivo

#### `GET /api/prestadores/:id`
#### `PATCH /api/prestadores/:id`
#### `DELETE /api/prestadores/:id`

#### `POST /api/prestadores/:id/documentos`
Associa upload existente a documento tipado.

**Entrada**
- `tipo: nativeEnum(TipoDocumentoPrestador)`
- `nome: string().min(1).max(160)`
- `descricao?: string().max(1000)`
- `uploadId: string().cuid()`

### 4.8 Lista de compras

#### `GET /api/compras`
**Query**
- `search?`
- `comprado?`
- `urgencia?`
- `categoria?`
- paginação/ordenação

#### `POST /api/compras`
**Entrada**
- `nome: string().min(1).max(160)`
- `quantidade?: coerce.number().positive()`
- `unidade?: string().max(30)`
- `localCompra?: string().max(160)`
- `urgencia: nativeEnum(Urgencia)`
- `categoria: nativeEnum(CategoriaProduto)`
- `observacao?: string().max(1000)`
- `valorEstimado?: coerce.number().nonnegative()`
- `valorReal?: coerce.number().nonnegative()`
- `uploadIds?: array(string().cuid()).max(5)`

#### `PATCH /api/compras/:id/toggle-bought`
Atualiza `comprado` e opcionalmente `dataCompra`.

#### `POST /api/compras/:id/duplicate`
Duplica item mantendo referência em `origemItemId`.

#### `GET /api/compras/:id`
#### `PATCH /api/compras/:id`
#### `DELETE /api/compras/:id`

### 4.9 Metas

#### `GET /api/metas`
**Query**
- `search?`
- `status?`
- `categoria?`
- `prioridade?`
- `concluidas?`
- paginação/ordenação

#### `POST /api/metas`
**Entrada**
- `titulo: string().min(1).max(160)`
- `descricao?: string().max(3000)`
- `categoria: nativeEnum(CategoriaMeta)`
- `prazo?: coerce.date()`
- `status?: nativeEnum(StatusMeta)`
- `prioridade: nativeEnum(Prioridade)`
- `motivacao?: string().max(3000)`
- `uploadIds?: array(string().cuid()).max(10)`

#### `GET /api/metas/:id`
#### `PATCH /api/metas/:id`
#### `DELETE /api/metas/:id`

#### `POST /api/metas/:id/marcos`
**Entrada**
- `titulo: string().min(1).max(160)`
- `descricao?: string().max(1000)`
- `ordem: number().int().min(1)`

#### `PATCH /api/metas/:id/marcos/:marcoId`
#### `DELETE /api/metas/:id/marcos/:marcoId`
#### `PATCH /api/metas/:id/marcos/:marcoId/toggle`

#### `POST /api/metas/:id/diario`
**Entrada**
- `conteudo: string().min(1).max(5000)`
- `humor?: string().max(40)`
- `uploadIds?: array(string().cuid()).max(5)`

#### `GET /api/metas/:id/diario`
#### `PATCH /api/metas/:id/diario/:entradaId`
#### `DELETE /api/metas/:id/diario/:entradaId`

### 4.10 Uploads

#### `POST /api/uploads`
Recebe `multipart/form-data`.

**Campos**
- `file`
- `entityType`
- `entityId?`
- `modulo`
- `categoria?`

**Resposta**
- metadados do upload

**Erros**
- `400 VALIDATION_ERROR`
- `401 UNAUTHORIZED`
- `413 PAYLOAD_TOO_LARGE`
- `415 UNSUPPORTED_FILE_TYPE`

#### `GET /api/uploads/:id`
Retorna stream autenticado para preview/download.

#### `DELETE /api/uploads/:id`
Remove metadado e arquivo físico se autorizado.

### 4.11 Busca global

#### `GET /api/search/global?q=...`
Retorna resultados agrupados por módulo:
- agenda
- serviços
- contas
- prestadores
- compras
- metas

### 4.12 Notificações

#### `GET /api/notifications`
#### `PATCH /api/notifications/:id/read`
#### `PATCH /api/notifications/read-all`

---

## 5. Design system

## 5.1 Tokens de cor
Aplicar como base do tema Tailwind e CSS variables.

- `background: #0F1117`
- `surface: #1A1D27`
- `border: #2A2D3A`
- `foreground: #E2E8F0`
- `muted-foreground: #94A3B8`
- `primary: #2D7DD2`
- `success: #10B981`
- `warning: #F59E0B`
- `destructive: #EF4444`

### Mapeamento sugerido
- `--background: 222 23% 7%`
- `--card: 225 20% 13%`
- `--border: 225 16% 20%`
- `--foreground: 210 40% 91%`
- `--muted-foreground: 215 20% 65%`
- `--primary: 211 65% 50%`
- `--success: 160 84% 39%`
- `--warning: 38 92% 50%`
- `--destructive: 0 84% 60%`

## 5.2 Componentes shadcn/ui a instalar
- `button`
- `input`
- `textarea`
- `label`
- `form`
- `select`
- `dialog`
- `alert-dialog`
- `sheet`
- `dropdown-menu`
- `popover`
- `calendar`
- `card`
- `table`
- `tabs`
- `badge`
- `toast` / `sonner`
- `separator`
- `skeleton`
- `avatar`
- `tooltip`
- `command`
- `scroll-area`
- `checkbox`
- `switch`
- `pagination`

## 5.3 Componentes base custom
- `AppSidebar`
- `AppHeader`
- `PageHeader`
- `StatCard`
- `StatusBadge`
- `DataTable`
- `EmptyState`
- `ConfirmDeleteDialog`
- `FileUploader`
- `GlobalSearchCommand`
- `InlineEditableField`
- `ModuleSummaryBar`

## 5.4 Padrões obrigatórios
- **Card**: header, content, footer opcionais; superfície `#1A1D27`; borda sutil.
- **Modal**: dialog para create/edit e confirm delete com foco inicial seguro.
- **Toast**: sucesso, erro, aviso, info padronizados.
- **Date picker**: `Popover + Calendar`, formato local pt-BR.
- **File uploader**: drag-and-drop opcional, preview, restrições visíveis, remoção antes do submit.
- **Badge de status**:
  - verde: sucesso/ativo/pago/concluído
  - amarelo: alerta/pendente/próximo
  - vermelho: atrasado/perigo/erro
  - cinza: pausado/inativo/cancelado/baixa urgência
- **Tabela**: sort, paginação, filtros, estado vazio, loading e ações inline.
- **Sidebar colapsável**: desktop com collapse, mobile com sheet/hambúrguer.
- **Search global**: atalho, overlay, resultados agrupados por módulo.

## 5.5 Tipografia
- Fonte principal: **Inter**.
- Fonte mono opcional: **JetBrains Mono** para IDs, tokens e URLs.
- Escala sugerida:
  - `text-3xl` títulos de página
  - `text-2xl` subtítulos principais
  - `text-xl` cards destacados
  - `text-base` corpo padrão
  - `text-sm` suporte
  - `text-xs` metadata

## 5.6 Espaçamento
- Base 4px pelo scale do Tailwind.
- Cards: `p-4` mobile, `p-6` desktop.
- Grid de dashboard: gap `4` mobile / `6` desktop.
- Formulários: espaçamento vertical `4`.

## 5.7 Breakpoints
- Mobile: `< 768px`
- Tablet: `>= 768px e < 1280px`
- Desktop: `>= 1280px`

---

## 6. Roadmap de implementação

## F0. Bootstrap
**Objetivo**
Criar a base do projeto com stack, banco e convenções iniciais.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/package.json`
- `C:/Users/Marco/projects/myfuckinglife/app/layout.tsx`
- `C:/Users/Marco/projects/myfuckinglife/app/globals.css`
- `C:/Users/Marco/projects/myfuckinglife/tailwind.config.ts`
- `C:/Users/Marco/projects/myfuckinglife/components.json`
- `C:/Users/Marco/projects/myfuckinglife/prisma/schema.prisma`
- `C:/Users/Marco/projects/myfuckinglife/.env.example`
- `C:/Users/Marco/projects/myfuckinglife/docker-compose.yml`
- `C:/Users/Marco/projects/myfuckinglife/lib/prisma.ts`

**Critérios de aceite**
- aplicação sobe localmente;
- PostgreSQL sobe via Docker;
- Prisma conecta ao banco;
- tokens de tema aplicados;
- shadcn/ui funcional.

**Dependências**
- nenhuma.

## F1. Auth
**Objetivo**
Implementar cadastro, login, reset de senha, middleware e layout protegido.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(auth)/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/auth/**`
- `C:/Users/Marco/projects/myfuckinglife/middleware.ts`
- `C:/Users/Marco/projects/myfuckinglife/lib/auth/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/email/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/auth.ts`

**Critérios de aceite**
- usuário consegue cadastrar e autenticar;
- rotas privadas redirecionam corretamente;
- reset envia email e invalida token após uso;
- todas as rotas privadas exigem sessão.

**Dependências**
- F0.

## F2. Layout + Sidebar + Search global
**Objetivo**
Construir a casca navegável autenticada.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/layout.tsx`
- `C:/Users/Marco/projects/myfuckinglife/components/layout/**`
- `C:/Users/Marco/projects/myfuckinglife/components/search/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/search/global/route.ts`

**Critérios de aceite**
- sidebar colapsa no desktop e vira drawer no mobile;
- busca global abre por atalho e retorna resultados mockados ou reais mínimos;
- navegação entre módulos funcional.

**Dependências**
- F1.

## F3. Dashboard
**Objetivo**
Entregar dashboard inicial com cards, listas resumidas e mocks temporários onde necessário.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/dashboard/page.tsx`
- `C:/Users/Marco/projects/myfuckinglife/components/dashboard/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/dashboard/summary/route.ts`

**Critérios de aceite**
- dashboard exibe cards e blocos de resumo;
- dados podem ser mockados no início e refinados ao final;
- layout responsivo consistente.

**Dependências**
- F2.

## F4. Agenda
**Objetivo**
Implementar CRUD completo da agenda com filtros, visualizações e alertas do dia.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/agenda/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/agenda/**`
- `C:/Users/Marco/projects/myfuckinglife/components/agenda/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/agenda.ts`

**Critérios de aceite**
- criar, editar, excluir e listar compromissos;
- views mensal, semanal e lista;
- filtros por tipo/período;
- destaque para compromissos do dia.

**Dependências**
- F2.

## F5. Acessos / Assinaturas
**Objetivo**
Implementar CRUD com senha criptografada, logo, comprovantes, total mensal e alerta de vencimento.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/servicos/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/servicos/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/crypto/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/servicos.ts`

**Critérios de aceite**
- cadastro e edição completos;
- senha pode ser revelada sob autenticação;
- total mensal calculado no topo;
- alerta de 7 dias para vencimento.

**Dependências**
- F2, F0.

## F6. Contas a pagar
**Objetivo**
Entregar CRUD, resumos financeiros, atraso automático e marcação inline de pagamento.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/contas/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/contas/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/contas.ts`

**Critérios de aceite**
- contas podem ser criadas, editadas, excluídas e pagas;
- status `ATRASADA` calculado automaticamente quando aplicável;
- resumo total/pago/pendente/atraso visível;
- filtros por mês/status funcionam.

**Dependências**
- F2.

## F7. Prestadores
**Objetivo**
Entregar cadastro completo, dados contratuais, documentos e alertas de pagamento.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/prestadores/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/prestadores/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/prestadores.ts`

**Critérios de aceite**
- CRUD completo de prestadores;
- upload e tipagem de documentos;
- alerta de próximo pagamento em 3 dias;
- filtros por status/vínculo.

**Dependências**
- F2, F8 uploads base.

## F8. Lista de compras
**Objetivo**
Implementar CRUD, urgência, anexo, marcação de compra, contadores e duplicação.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/compras/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/compras/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/compras.ts`

**Critérios de aceite**
- item pode ser marcado como comprado inline;
- urgência colorida visível;
- contadores de pendentes/comprados;
- duplicação de item anterior funcional;
- valor estimado vs real comparável.

**Dependências**
- F2.

## F9. Metas
**Objetivo**
Implementar CRUD de metas, marcos, diário, progresso automático e concluídas.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/metas/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/metas/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/validations/metas.ts`

**Critérios de aceite**
- meta possui marcos e entradas de diário;
- progresso é calculado automaticamente por marcos concluídos;
- seção de concluídas disponível;
- anexos de inspiração suportados.

**Dependências**
- F2.

## F10. Notificações globais + polish + QA
**Objetivo**
Fechar o sistema com notificações internas, responsividade, estados de erro/loading e revisão final.

**Arquivos criados/modificados**
- `C:/Users/Marco/projects/myfuckinglife/app/(dashboard)/notificacoes/**`
- `C:/Users/Marco/projects/myfuckinglife/app/api/notifications/**`
- `C:/Users/Marco/projects/myfuckinglife/components/shared/**`
- `C:/Users/Marco/projects/myfuckinglife/lib/notifications/**`

**Critérios de aceite**
- notificações in-app funcionam por módulo;
- telas responsivas mobile/tablet/desktop;
- toasts, erros vazios e confirmações consistentes;
- revisão final do dashboard usando dados reais.

**Dependências**
- F3 a F9.

---

## 7. Regras de negócio transversais

## 7.1 Status calculados
- `Conta.status = ATRASADA` quando `status != PAGA` e `vencimento < hoje`.
- `Servico.status` pode ser `ATRASADO` por cálculo de vencimento, mas o valor persistido pode refletir o estado operacional do serviço. Recomenda-se expor também `statusCalculado` no response.
- `Meta.progresso` deve ser derivado de `marcos concluídos / total de marcos` quando houver marcos.

## 7.2 Alertas
- Agenda: alerta do dia.
- Serviços: alerta 7 dias antes do vencimento.
- Prestadores: alerta 3 dias antes do pagamento.
- Contas: atraso imediato após vencimento.

## 7.3 Exclusão
- Sempre com confirmação explícita na UI.
- Exclusão de entidades com uploads deve disparar limpeza de metadados e arquivo físico.

## 7.4 Busca global
- Indexar por `nome`, `titulo`, `descricao`, `observacao`, `email`, `url` quando aplicável.
- Resposta agrupada por módulo e limitada por tipo.

---

## 8. Pontos de risco e decisões pendentes

## 8.1 Criptografia das senhas de serviços
**Decisão proposta**: **AES-256-GCM** com chave em `ENCRYPTION_KEY` no `.env`.

**Justificativa**
- as senhas precisam ser reveladas/copiadas, logo hash unidirecional não atende;
- GCM oferece confidencialidade + integridade;
- armazenar `ciphertext`, `iv` e `authTag` por registro.

**Rejeitado**
- bcrypt/argon2 para esse campo, porque não permite recuperação.

## 8.2 Email de reset
**Decisão proposta**: usar **Resend** como provider principal, com abstração para fallback SMTP/Nodemailer.

**Justificativa**
- onboarding simples;
- melhor DX para projeto novo;
- mantém liberdade futura via adapter local.

**Estratégia**
- `lib/email/send-email.ts` com interface única;
- provider selecionado por env.

## 8.3 Preview de PDF
**Decisão proposta**: preview autenticado por endpoint de stream com `Content-Disposition: inline`.

**Justificativa**
- evita exposição pública dos arquivos;
- mantém autorização por usuário;
- PDF e imagem seguem mesma política.

## 8.4 Upload genérico vs por módulo
**Decisão proposta**: **genérico centralizado**.

**Justificativa**
- reduz redundância;
- facilita limpeza, auditoria e gestão de storage;
- suporta vários cenários sem multiplicar tabelas.

**Cuidado**
- service layer deve sempre validar `entityType + entityId + userId` antes de associar.

## 8.5 Server Actions vs REST puro
**Decisão proposta**: abordagem híbrida com **REST como contrato principal**.

**Justificativa**
- melhora clareza do backend e testabilidade;
- uploads e status codes ficam mais simples;
- mantém Server Actions para interações pequenas.

## 8.6 Recorrência
**Risco**
- recorrência pode explodir complexidade se gerar infinitas instâncias.

**Solução proposta**
- persistir regra de recorrência no registro mestre;
- expandir ocorrências apenas na janela consultada para agenda/listagens futuras;
- contas recorrentes podem gerar próximas instâncias por job local ou na confirmação de fechamento do período.

## 8.7 Arquivos órfãos
**Risco**
- falhas entre banco e filesystem podem deixar lixo no disco.

**Solução proposta**
- usar fluxo de upload em duas etapas: salvar arquivo, gravar metadado, vincular entidade;
- agendar rotina de limpeza de temporários;
- remover arquivo ao falhar persistência final.

## 8.8 Ambiguidades ainda existentes no briefing
Mesmo com o briefing detalhado, estas definições devem ser confirmadas antes da execução fina:
- se `Servico.status` será 100% persistido, 100% calculado, ou híbrido;
- se contas recorrentes devem auto-gerar próximas parcelas automaticamente;
- se prestadores admitem múltiplos contratos futuros por pessoa ou apenas um vínculo ativo por cadastro;
- se diário de metas aceita rich text ou texto simples;
- se busca global deve buscar conteúdo de anexos/PDF ou apenas metadados.

**Recomendação atual**
- status híbrido para serviço;
- geração automática apenas da próxima ocorrência, não lote infinito;
- um vínculo principal por prestador nesta primeira versão;
- diário em texto simples com markdown leve opcional no futuro;
- busca global apenas em metadados e campos textuais, não dentro de PDF nesta fase.

---

## 9. Estratégia de verificação e Definition of Done

## 9.1 Verificações por fase
- migração Prisma aplica sem erro;
- schemas Zod validam entradas válidas e rejeitam inválidas;
- APIs privadas negam acesso sem sessão;
- queries não retornam dados de outro usuário;
- uploads bloqueiam tipo/tamanho inválidos;
- UI responsiva em mobile/tablet/desktop;
- status calculados e badges refletem regras de negócio.

## 9.2 DoD global
Uma fase está concluída quando:
- código compila;
- fluxo principal do módulo funciona ponta a ponta;
- CRUD cobre create/read/update/delete aplicáveis;
- filtros principais funcionam;
- validação e mensagens de erro estão coerentes;
- rotas respeitam autenticação e `userId`;
- telas seguem o design system.

## 9.3 Traceabilidade fase → alvos → verificação

| Fase | Alvos principais | Verificação |
|------|------------------|-------------|
| F0 | base do projeto, Prisma, tema, Docker | app sobe, DB conecta, migração inicial aplica |
| F1 | auth, middleware, reset | login/cadastro/reset funcionam e protegem rotas |
| F2 | layout autenticado, sidebar, search | navegação e busca global funcionam |
| F3 | dashboard | cards e resumos renderizam corretamente |
| F4 | agenda | CRUD + views + alertas do dia |
| F5 | serviços | CRUD + cifra/revelação + alerta 7 dias |
| F6 | contas | CRUD + atraso automático + marcar pago |
| F7 | prestadores | CRUD + documentos + alerta pagamento |
| F8 | compras | CRUD + comprado inline + duplicação |
| F9 | metas | CRUD + marcos + diário + progresso auto |
| F10 | notificações, polish, QA | sistema consistente e responsivo |

---

## 10. Entregável final e fonte de verdade

## 10.1 Arquivo canônico
O plano arquitetural consolidado deve ser mantido em:

`C:/Users/Marco/projects/myfuckinglife/docs/PLAN.md`

## 10.2 Papel do arquivo
Esse documento será a **fonte de verdade** para:
- estrutura do projeto;
- schema Prisma;
- contratos de API;
- design system;
- implementação faseada;
- decisões técnicas aprovadas.

## 10.3 Próximo passo após aprovação
Após aprovação, executar nesta ordem:
1. materializar `C:/Users/Marco/projects/myfuckinglife/docs/PLAN.md`;
2. bootstrap da fase F0;
3. seguir fases sequencialmente com validação ao final de cada entrega.
